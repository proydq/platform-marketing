<template>
  <div class="page-wrapper">
  <el-card>
    <h2>📄 功能开发中</h2>
    <p>该功能尚在开发中，敬请期待...</p>
  </el-card>
</div>

</template>
<script setup>
</script>
