<template>
  <div class="page-wrapper">
  <el-card>
    <h2>📄 帮助中心</h2>
    <p>这里提供系统使用文档和常见问题解答。</p>
  </el-card>
</div>
</template>
<script setup>
</script>
