<template>
  <el-input v-model="model" type="textarea" rows="5" />
</template>
<script setup>
const model = defineModel()
</script>
