<template>
  <el-dialog title="Create Role" v-model="visible">
    <p>Create role form here</p>
  </el-dialog>
</template>

<script setup>
import { ref } from 'vue'
const visible = ref(false)
</script>
